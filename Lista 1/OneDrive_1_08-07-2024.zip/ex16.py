km=float(input("Digite uma distância em quilômetros: "))
mil=km/1.61
print(f"Essa distância em milhas é: {mil}")