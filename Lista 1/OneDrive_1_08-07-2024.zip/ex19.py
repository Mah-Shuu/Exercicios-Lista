pole=float(input("Digite um comprimento em polegadas: "))
cent=pole*2.54
print(f"O comprimento em centímetros é: {cent}")