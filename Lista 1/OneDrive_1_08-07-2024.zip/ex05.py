num=float(input("Digite um número real: "))
res=num/5.0
print(f"A quinta parte desse número é: {res}")