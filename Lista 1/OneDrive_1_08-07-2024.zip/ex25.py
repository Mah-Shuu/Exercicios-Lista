jard=float(input("Digite um comprimento em jardas: "))
m=0.91* jard
print(f"Esse comprimento em metros é: {m}")