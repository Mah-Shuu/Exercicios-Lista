far=float(input("Digite um valor em Fahrenheit: "))

celsius= 5.0*(far-32.0)/9.0

print(f"Convertido para Celsius dá: {celsius}")