milha=float(input("Digite uma distância em milhas: "))
km=1.61*milha
print(f"Essa distância em kilometros é: {km}")