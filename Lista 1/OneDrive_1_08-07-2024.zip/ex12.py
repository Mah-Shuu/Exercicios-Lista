celsius=float(input("Digite um valor em Celsius: "))

kel= celsius + 273.15

print(f"Convertido para Kelvin dá: {kel}")