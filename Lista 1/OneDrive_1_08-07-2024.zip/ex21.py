cubo=float(input("Digite um volume em metros cúbicos: "))
litro=1000*cubo
print(f"Esse volume em litros é: {litro}")