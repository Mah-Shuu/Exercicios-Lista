num=int(input("Digite um número: "))
numa=num-1
nums=num+1
print(f"Seu antecessor é: {numa}\nSeu sucessor é: {nums}")