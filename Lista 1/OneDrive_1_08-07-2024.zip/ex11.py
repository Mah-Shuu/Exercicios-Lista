kel=float(input("Digite um valor em Kelvin: "))

celsius= kel - 273.15

print(f"Convertido para Celsius dá: {celsius}")