grau=float(input("Digite um ângulo em graus: "))
rad= grau * 3.14/180
print(f"Esse ângulo em radianos é: {rad}")