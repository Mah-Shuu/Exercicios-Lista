km=float(input("Digite uma velocidade em km/h: "))
ms=km/3.6
print(f"Essa velocidade em m/s é: {ms}")