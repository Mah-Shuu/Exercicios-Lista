num1=int(input("Digite um número: "))
num2=int(input("Digite outro número: "))
num3=int(input("Digite outro número: "))

soma=num1+num2+num3

print(f"A soma dos números é: {soma}")