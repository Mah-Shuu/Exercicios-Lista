litro=float(input("Digite um volume em litros: "))
cubo=litro/1000
print(f"Esse volume em metros cúbicos é: {cubo}")