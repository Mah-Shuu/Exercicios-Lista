num=int(input("Digite um número inteiro: "))
print(f"Número digitado: {num}")