raio=float(input("Digite o raio de um círculo"))
a=3.141592*(raio*raio)
print(f"A área do círculo é {a}cm² ou ",raio*raio,"π cm²")