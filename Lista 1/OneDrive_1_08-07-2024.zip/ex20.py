cent=float(input("Digite um comprimento em centímetros: "))
pole=cent/2.54
print(f"O comprimento em polegadas é: {pole}")