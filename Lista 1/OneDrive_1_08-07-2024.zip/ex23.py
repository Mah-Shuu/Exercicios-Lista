kg=float(input("Digite um valor de massa em kg: "))
libras=kg/0.45
print(f"Essa massa em libras é: {libras}")