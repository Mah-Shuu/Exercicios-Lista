num=float(input("Digitr um número real: "))
res=num*num
print(f"O quadrado do número é: {res}")