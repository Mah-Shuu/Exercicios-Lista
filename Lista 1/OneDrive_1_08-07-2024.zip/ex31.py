real=float(input("Digite um valor em reais: "))
cdolar=float(input("Digite a cotação do dólar: "))
res=real/cdolar
print(f"Seu valor de reais em dólares é: {res}")