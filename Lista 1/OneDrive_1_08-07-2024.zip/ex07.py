num=int(input("Digite um número: "))
st=(num*3)+1
ad=(num*2)-1
res=st+ad
print(f"A soma do sucessor de seu triplo com o antecessor de seu dobro é: {res}")