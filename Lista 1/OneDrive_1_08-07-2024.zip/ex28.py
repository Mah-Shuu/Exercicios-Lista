hec=float(input("Digite o valor de uma área em hectares: "))
mquad= hec*10000
print(f"Essa área em metros quadrados é: {mquad}")