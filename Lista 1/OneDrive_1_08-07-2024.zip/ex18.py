rad=float(input("Digite um ângulo em radianos: "))
grau= rad * 180/3.14
print(f"Esse ângulo em graus é: {grau}")