num=float(input("Digite um número real: "))
print(f"Número digitado: {num}")