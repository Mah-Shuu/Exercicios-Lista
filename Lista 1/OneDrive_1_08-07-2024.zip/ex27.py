mquad=float(input("Digite o valor de uma área em metros quadrados: "))
hec= mquad*0.0001
print(f"Essa área em hectares é: {hec}")