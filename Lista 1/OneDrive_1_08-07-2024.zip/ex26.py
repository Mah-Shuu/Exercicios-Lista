m=float(input("Digite um comprimento em metros: "))
jard=m/0.91
print(f"Esse comprimento em jardas é: {jard}")