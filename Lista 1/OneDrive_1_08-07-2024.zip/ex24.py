libras=float(input("Digite um valor de massa em libras: "))
kg=libras*0.45
print(f"Essa massa em quilogramas é: {kg}")