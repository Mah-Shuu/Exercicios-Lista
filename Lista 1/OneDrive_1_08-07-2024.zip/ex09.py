celsius=float(input("Digite um valor em Celsius: "))

far=celsius*(9.0/5.0)+32.0

print(f"Convertido para Fahrenheit dá: {far}")