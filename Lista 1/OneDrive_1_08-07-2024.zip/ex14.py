ms=float(input("Digite uma velocidade em m/s: "))
km=ms*3.6
print(f"Essa velocidade em km/h é: {km}")